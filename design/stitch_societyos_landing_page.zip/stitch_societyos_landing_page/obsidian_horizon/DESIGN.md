# Design System Theme

## Overview
This document outlines the core aesthetic principles and design token values that define our digital product's look and feel. It serves as a single source of truth for design decisions, ensuring consistency and brand cohesion across all platforms.

## Color Palette

### Color Mode
The theme is set to `dark` mode, providing a modern and comfortable viewing experience, especially in low-light environments.

### Primary Colors
The core of our visual identity is built around a monochrome palette.
- **Primary Color**: `#777777` - A balanced gray, used for primary actions, key interactive elements, and brand accents.
- **Secondary Color**: `#777777` - A consistent gray, supporting less prominent UI elements, secondary actions, and informational components.
- **Tertiary Color**: `#777777` - A uniform gray, providing an additional accent for highlights, badges, or decorative elements.
- **Neutral Color**: `#777777` - A foundational gray, serving as the base for backgrounds, surfaces, and non-chromatic UI elements.

## Typography

### Font Families
We utilize the 'Inter' typeface across all textual elements for a clean, modern, and highly legible experience.
- **Headline Font**: `inter` - Applied to all major headings and titles, ensuring strong hierarchy.
- **Body Font**: `inter` - Used for all paragraph text, lists, and general content, optimizing for readability.
- **Label Font**: `inter` - Employed for form labels, buttons, and other interactive text, maintaining consistency in interactive elements.

## Shape and Spacing

### Roundedness
UI elements feature a `moderate` level of roundedness (value `2`), striking a balance between modern softness and structured clarity. This applies to buttons, cards, input fields, and other container elements.

### Spacing
The design employs `normal` spacing (value `2`), providing a balanced amount of whitespace between and within UI elements. This ensures content breathability without feeling overly dense or sparse.